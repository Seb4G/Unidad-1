#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>

using namespace sf;

int main() {
    RenderWindow App(VideoMode(800, 600), "Pelota Rebotando");
    Event evt;
    b2Vec2 gravedad(0.1f, 0.1f);
    b2World world(gravedad);
    b2BodyDef defPelota;
    defPelota.type = b2_dynamicBody;
    defPelota.position.Set(4.0f, 1.0f);
    b2Body* bodyPelota = world.CreateBody(&defPelota);
    b2CircleShape shapePelota;
    shapePelota.m_radius = 0.5f;
    b2FixtureDef fixtureDefPelota;
    fixtureDefPelota.shape = &shapePelota;
    fixtureDefPelota.density = 1.0f;
    fixtureDefPelota.friction = 5.0f;
    fixtureDefPelota.restitution = 1.0f;
    bodyPelota->CreateFixture(&fixtureDefPelota);

    b2Vec2 velocidadInicial(0.9f, 0.9f);
    bodyPelota->SetLinearVelocity(velocidadInicial);
    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed)
                App.close();
        }
        world.Step(1/60.0f, 10, 10);
        b2Vec2 posicion = bodyPelota->GetPosition();
        if (posicion.x * 50 < shapePelota.m_radius || posicion.x * 50 > 800 - shapePelota.m_radius) {
            bodyPelota->SetLinearVelocity(b2Vec2(-bodyPelota->GetLinearVelocity().x, bodyPelota->GetLinearVelocity().y));
        }
        if (posicion.y * 50 < shapePelota.m_radius || posicion.y * 50 > 600 - shapePelota.m_radius) {
            bodyPelota->SetLinearVelocity(b2Vec2(bodyPelota->GetLinearVelocity().x, -bodyPelota->GetLinearVelocity().y));
        }
        App.clear();
        CircleShape pelota(shapePelota.m_radius * 50);
        pelota.setFillColor(Color::Red);
        pelota.setPosition(bodyPelota->GetPosition().x * 50, bodyPelota->GetPosition().y * 50);
        pelota.setOrigin(pelota.getRadius(), pelota.getRadius());
        App.draw(pelota);
        App.display();
    }
    return 0;
}
#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>

using namespace sf;

int main() {
    RenderWindow App(VideoMode(800, 600), "Juego del Ca�on");
    Event evt;
    b2Vec2 gravity(0.0f, 0.0f);
    b2World world(gravity);
    b2BodyDef pisoBodyDef;
    pisoBodyDef.position.Set(400.0f, 600.0f);
    b2Body* pisoBody = world.CreateBody(&pisoBodyDef);
    b2PolygonShape pisoBox;
    pisoBox.SetAsBox(800.0f, 10.0f);
    pisoBody->CreateFixture(&pisoBox, 0.0f);

    b2BodyDef ca�onBodyDef;
    ca�onBodyDef.position.Set(50.0f, 300.0f);
    b2Body* ca�onBody = world.CreateBody(&ca�onBodyDef);
    b2PolygonShape ca�onBox;
    ca�onBox.SetAsBox(25.0f, 10.0f);
    b2FixtureDef ca�onFixtureDef;
    ca�onFixtureDef.shape = &ca�onBox;
    ca�onFixtureDef.density = 1.0f;
    ca�onFixtureDef.friction = 0.3f;
    ca�onBody->CreateFixture(&ca�onFixtureDef);
    b2BodyDef proyectilBodyDef;
    proyectilBodyDef.type = b2_dynamicBody;
    proyectilBodyDef.position.Set(50.0f, 300.0f);
    b2Body* proyectilBody = world.CreateBody(&proyectilBodyDef);
    b2CircleShape proyectilCircle;
    proyectilCircle.m_radius = 5.0f;
    b2FixtureDef proyectilFixtureDef;
    proyectilFixtureDef.shape = &proyectilCircle;
    proyectilFixtureDef.density = 2.0f;
    proyectilFixtureDef.friction = 1.5f;
    proyectilFixtureDef.restitution = 0.5f;
    proyectilBody->CreateFixture(&proyectilFixtureDef);

    float angulo = 25.0f;
    float poder = 2000.0f;
    bool seDisparo = false;
    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed)
                App.close();
            if (evt.type == Event::KeyPressed && evt.key.code == Keyboard::Space) {
                seDisparo = true;
                b2Vec2 fuerza(poder * cos(angulo * b2_pi / 180.0f), -poder * sin(angulo * b2_pi / 180.0f));
                proyectilBody->ApplyLinearImpulse(fuerza, proyectilBody->GetWorldCenter(), true);
                world.SetGravity(b2Vec2(0.0f, 0.7f));
            }
            if (evt.type == Event::KeyReleased && evt.key.code == Keyboard::Space)
                seDisparo = false;
            if (evt.type == Event::KeyPressed && evt.key.code == Keyboard::Up)
                angulo += 5.0f;
            if (evt.type == Event::KeyPressed && evt.key.code == Keyboard::Down)
                angulo -= 5.0f;
        }
        world.Step(1/60.0f, 10, 10);
        ca�onBody->SetTransform(ca�onBody->GetPosition(), angulo * b2_pi / 180.0f);
        App.clear();

        RectangleShape piso(Vector2f(800, 10));
        piso.setPosition(0, 590);
        App.draw(piso);
        RectangleShape ca�on(Vector2f(50, 20));
        ca�on.setFillColor(Color::Green);
        ca�on.setOrigin(25, 10);
        ca�on.setPosition(ca�onBody->GetPosition().x, ca�onBody->GetPosition().y);
        ca�on.setRotation(ca�onBody->GetAngle() * 180.0f / b2_pi);
        App.draw(ca�on);
        CircleShape proyectil(5);
        proyectil.setFillColor(Color::Red);
        proyectil.setPosition(proyectilBody->GetPosition().x, proyectilBody->GetPosition().y);
        App.draw(proyectil);
        App.display();
    }
    return 0;
}
#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>

using namespace sf;

int main() {
    RenderWindow App(VideoMode(800, 600), "Bloque Cayendo");
    Event evt;
    b2Vec2 gravedad(0.0f, 2.0f);
    b2World world(gravedad);
    b2BodyDef bodyDefPiso;
    bodyDefPiso.position.Set(400, 500);
    b2Body* bodyPiso = world.CreateBody(&bodyDefPiso);
    b2PolygonShape boxPiso;
    boxPiso.SetAsBox(400, 10);
    bodyPiso->CreateFixture(&boxPiso, 0.0f);

    b2BodyDef bloqBodyDef;
    bloqBodyDef.type = b2_dynamicBody;
    bloqBodyDef.position.Set(400, 100);
    b2Body* bloqBody = world.CreateBody(&bloqBodyDef);
    b2PolygonShape bloqkBox;
    bloqkBox.SetAsBox(20, 20);
    b2FixtureDef bloqFixtureDef;
    bloqFixtureDef.shape = &bloqkBox;
    bloqFixtureDef.density = 0.5f;
    bloqFixtureDef.friction = 0.5f;
    bloqBody->CreateFixture(&bloqFixtureDef);
    RectangleShape Bloque(Vector2f(100, 100));
    Bloque.setFillColor(Color::Red);
    Bloque.setOrigin(50, 50);
    Bloque.setPosition(400, 200);

    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed)
                App.close();
        }
        world.Step(1/60.0f, 10, 10);
        App.clear();

        RectangleShape pisoShape(Vector2f(800, 20));
        pisoShape.setFillColor(Color::Blue);
        pisoShape.setOrigin(400, 10);
        pisoShape.setPosition(400, 500);
        App.draw(pisoShape);
        RectangleShape bloqShape(Vector2f(40, 40));
        bloqShape.setFillColor(Color::Red);
        bloqShape.setOrigin(20, 20);
        bloqShape.setPosition(bloqBody->GetPosition().x, bloqBody->GetPosition().y);
        bloqShape.setRotation(bloqBody->GetAngle() * 180 / b2_pi);
        App.draw(bloqShape);
        App.display();
    }

    return 0;
}
#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>

using namespace sf;

int main() {
    RenderWindow App(VideoMode(800, 600), "Caja Deslizante");
    Event evt;
    b2Vec2 gravedad(0.0f, 0.0f);
    b2World world(gravedad);
    b2BodyDef pisoDef;
    pisoDef.position.Set(0.0f, 20.0f);
    b2Body* piso = world.CreateBody(&pisoDef);
    b2PolygonShape pisoShape;
    pisoShape.SetAsBox(1500.0f, 15.0f);
    piso->CreateFixture(&pisoShape, 0.0f);

    b2BodyDef cajaDef;
    cajaDef.type = b2_dynamicBody;
    cajaDef.position.Set(0.0f, 150.0f);
    b2Body* caja = world.CreateBody(&cajaDef);
    b2PolygonShape cajaShape;
    cajaShape.SetAsBox(30.0f, 30.0f);
    b2FixtureDef cajaFixtureDef;
    cajaFixtureDef.shape = &cajaShape;
    cajaFixtureDef.density = 2.2;
    cajaFixtureDef.friction = 0.02;
    caja->CreateFixture(&cajaFixtureDef);

    float fuerza = 300.0f;
    float velocidad = 0.0f;
    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed)
                App.close();
        }
        if (Keyboard::isKeyPressed(Keyboard::Left)) {
            caja->ApplyForceToCenter(b2Vec2(-fuerza, 0.0f), true);
        }
        if (Keyboard::isKeyPressed(Keyboard::Right)) {
            caja->ApplyForceToCenter(b2Vec2(fuerza, 0.0f), true);
        }
        world.Step(1/60.0f, 10, 10);
        b2Vec2 posicion = caja->GetPosition();
        float posX = posicion.x;
        float posY = App.getSize().y - posicion.y;
        App.clear();

        RectangleShape pisoShape(Vector2f(3000.0f, 10.0f));
        pisoShape.setFillColor(Color::Green);
        pisoShape.setPosition(-1500.0f, 480.0f);
        App.draw(pisoShape);
        RectangleShape cajaShape(Vector2f(60.0f, 60.0f));
        cajaShape.setFillColor(Color::Blue);
        cajaShape.setOrigin(30.0f, 30.0f);
        cajaShape.setPosition(posX, posY);
        App.draw(cajaShape);
        App.display();
    }

    return 0;
}

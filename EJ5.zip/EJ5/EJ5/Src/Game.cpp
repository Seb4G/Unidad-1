#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>

using namespace sf;

int main() {
    RenderWindow App(VideoMode(800, 600), "Cuadrado en la Colina");
    Event evt;
    b2Vec2 gravedad(0.0f, 0.5f);
    b2World world(gravedad);
    b2Vec2 v1(0, 500);
    b2Vec2 v2(800, 200);
    b2BodyDef pisoBodyDef;
    pisoBodyDef.position.Set(0, 0);
    b2Body* pisoBody = world.CreateBody(&pisoBodyDef);
    b2EdgeShape edge;
    edge.m_vertex1 = v1;
    edge.m_vertex2 = v2;
    b2FixtureDef edgeFixtureDef;
    edgeFixtureDef.shape = &edge;
    edgeFixtureDef.friction = 0.6f;
    pisoBody->CreateFixture(&edgeFixtureDef);

    b2BodyDef cuadBodyDef;
    cuadBodyDef.type = b2_dynamicBody;
    cuadBodyDef.position.Set(750, 100);
    b2Body* cuadBody = world.CreateBody(&cuadBodyDef);
    b2PolygonShape cuadBox;
    cuadBox.SetAsBox(20, 20);
    b2FixtureDef cuadFixtureDef;
    cuadFixtureDef.shape = &cuadBox;
    cuadFixtureDef.density = 1.0f;
    cuadBody->CreateFixture(&cuadFixtureDef);
    RectangleShape Cuadrado(Vector2f(40, 40));
    Cuadrado.setFillColor(Color::Red);
    Cuadrado.setOrigin(20, 20);
    Cuadrado.setPosition(400, 200);

    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed)
                App.close();
        }
        world.Step(1/60.0f, 10, 10);
        App.clear();

        VertexArray pisoShape(LinesStrip, 2);
        pisoShape[0].position = Vector2f(v1.x, v1.y);
        pisoShape[1].position = Vector2f(v2.x, v2.y);
        pisoShape[0].color = Color::Blue;
        pisoShape[1].color = Color::Blue;
        App.draw(pisoShape);
        RectangleShape cuadradoShape(Vector2f(40, 40));
        cuadradoShape.setFillColor(Color::Red);
        cuadradoShape.setOrigin(20, 20);
        cuadradoShape.setPosition(cuadBody->GetPosition().x, cuadBody->GetPosition().y);
        cuadradoShape.setRotation(cuadBody->GetAngle() * 180 / b2_pi);
        App.draw(cuadradoShape);
        App.display();
    }

    return 0;
}
#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>

using namespace sf;

int main() {
    RenderWindow App(VideoMode(800, 600), "Pelota Rebotando con Obstaculo");
    Event evt;
    b2Vec2 gravedad(0.0f, 0.4f);
    b2World world(gravedad);
    b2BodyDef defPelota;
    defPelota.type = b2_dynamicBody;
    defPelota.position.Set(0.0f, 1.0f);
    b2Body* bodyPelota = world.CreateBody(&defPelota);
    b2CircleShape shapePelota;
    shapePelota.m_radius = 0.5f;
    b2FixtureDef fixtureDefPelota;
    fixtureDefPelota.shape = &shapePelota;
    fixtureDefPelota.density = 4.0f;
    fixtureDefPelota.friction = 2.0f;
    fixtureDefPelota.restitution = 2.0f;
    bodyPelota->CreateFixture(&fixtureDefPelota);

    b2BodyDef cuadDef;
    cuadDef.type = b2_staticBody;
    cuadDef.position.Set(2.0f, 7.0f);
    b2Body* cuadBody = world.CreateBody(&cuadDef);
    b2PolygonShape cuadShape;
    cuadShape.SetAsBox(1.0f, 1.0f);
    cuadBody->CreateFixture(&cuadShape, 0.0f);
    b2BodyDef cuad2Def;
    cuad2Def.type = b2_staticBody;
    cuad2Def.position.Set(15.0f, 0.0f);
    b2Body* cuad2Body = world.CreateBody(&cuad2Def);
    b2PolygonShape cuad2Shape;
    cuad2Shape.SetAsBox(0.5f, 0.5f);
    cuad2Body->CreateFixture(&cuad2Shape, 0.0f);

    b2Vec2 velocidadInicial(1.0f, 1.0f);
    bodyPelota->SetLinearVelocity(velocidadInicial);
    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed)
                App.close();
        }
        world.Step(1 / 60.0f, 10, 10);
        b2Vec2 posicion = bodyPelota->GetPosition();
        if (posicion.x * 50 < shapePelota.m_radius || posicion.x * 50 > 800 - shapePelota.m_radius) {
            bodyPelota->SetLinearVelocity(b2Vec2(-bodyPelota->GetLinearVelocity().x, bodyPelota->GetLinearVelocity().y));
        }
        if (posicion.y * 50 < shapePelota.m_radius || posicion.y * 50 > 600 - shapePelota.m_radius) {
            bodyPelota->SetLinearVelocity(b2Vec2(bodyPelota->GetLinearVelocity().x, -bodyPelota->GetLinearVelocity().y));
        }
        App.clear();
        CircleShape pelota(shapePelota.m_radius * 50);
        pelota.setFillColor(Color::Red);
        pelota.setPosition(bodyPelota->GetPosition().x * 50, bodyPelota->GetPosition().y * 50);
        pelota.setOrigin(pelota.getRadius(), pelota.getRadius());
        App.draw(pelota);
        RectangleShape Cuadrado(Vector2f(100.0f, 100.0f));
        Cuadrado.setFillColor(Color::Blue);
        Cuadrado.setPosition(200.0f, 350.0f);
        Cuadrado.setOrigin(100.0f, 100.0f);
        App.draw(Cuadrado);
        RectangleShape Cuadrado2(Vector2f(400.0f, 400.0f));
        Cuadrado2.setFillColor(Color::Green);
        Cuadrado2.setPosition(750.0f, 0.0f);
        Cuadrado2.setOrigin(150.0f, 200.0f);
        App.draw(Cuadrado2);
        App.display();
    }
    return 0;
}